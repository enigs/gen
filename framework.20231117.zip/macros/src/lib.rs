pub use as_form_derive::AsForm;
pub use set_cipher_derive::SetCipher;
pub use set_is_empty_derive::SetIsEmpty;
pub use set_mutate_derive::SetMutate;

pub trait AsForm {}

pub trait SetCipher {}

pub trait SetIsEmpty {}

pub trait SetMutate {}