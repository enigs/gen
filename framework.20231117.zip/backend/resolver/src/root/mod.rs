pub mod mutation;
pub mod query;

pub use mutation::RootMutation;
pub use query::RootQuery;