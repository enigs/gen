pub mod actor;

pub use actor::Role;
